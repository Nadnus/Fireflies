//
// Created by hgallegos on 1/04/2022.
//

#include "Rayo.h"
