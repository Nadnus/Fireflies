#include <iostream>

#include "Mundo.h"

int main() {
    Mundo mundo;
    mundo.escenario1();
    return 0;
}
